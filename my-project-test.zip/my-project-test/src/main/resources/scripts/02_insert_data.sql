INSERT INTO oneclickpurchase (name, phone, email) VALUES ('Ivan', '8122404040', 'ivan@gmail.com');
INSERT INTO oneclickpurchase (name, phone, email) VALUES ('Sergey', '8123130101', 'sergey@gmail.com');
INSERT INTO oneclickpurchase (name, phone, email) VALUES ('Dmitry', '9819705310', 'dmitry@gmail.com');
INSERT INTO oneclickpurchase (name, phone, email) VALUES ('Mark', '9522218022', 'mark@gmail.com');
INSERT INTO oneclickpurchase (name, phone, email) VALUES ('Anton', '8007000055', 'anton@gmail.com');
